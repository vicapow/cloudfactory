/*
 *  HUDWidget.h
 *  CloudFactory
 *
 *  Created by Timothy Luciani on 4/16/11.
 *  Copyright 2011 University of Pittsburgh. All rights reserved.
 *
 */


#ifndef HUD_WIDGET
#define HUD_WIDGET

#include "BluePrintHUD.h"


class HUDWidget : public QWidget {
public:
	HUDWidget();
};

#endif